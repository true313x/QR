package com.qrx.scanner.presentation.generator

import com.qrx.scanner.R
import com.qrx.scanner.generator.QrDesign

/** Display name of a design. Unknown ids fall back to the classic name. */
val QrDesign.nameRes: Int
    get() = when (id) {
        "rounded" -> R.string.design_rounded
        "dots" -> R.string.design_dots
        "liquid" -> R.string.design_liquid
        "leaf" -> R.string.design_leaf
        "petal" -> R.string.design_petal
        "diamond" -> R.string.design_diamond
        "bars_h" -> R.string.design_bars_h
        "bars_v" -> R.string.design_bars_v
        "pixel" -> R.string.design_pixel
        "sunset" -> R.string.design_sunset
        "ocean" -> R.string.design_ocean
        "forest" -> R.string.design_forest
        "royal" -> R.string.design_royal
        "fire" -> R.string.design_fire
        "mint" -> R.string.design_mint
        "gold" -> R.string.design_gold
        "berry" -> R.string.design_berry
        "neon" -> R.string.design_neon
        "confetti" -> R.string.design_confetti
        "heart_pixel" -> R.string.design_heart_pixel
        "heart_red" -> R.string.design_heart_red
        "love" -> R.string.design_love
        "star" -> R.string.design_star
        "accent_eyes" -> R.string.design_accent_eyes
        "sky" -> R.string.design_sky
        else -> R.string.design_classic
    }
