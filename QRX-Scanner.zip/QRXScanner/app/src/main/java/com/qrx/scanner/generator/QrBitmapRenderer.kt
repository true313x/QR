package com.qrx.scanner.generator

import android.graphics.Bitmap
import android.graphics.Canvas
import javax.inject.Inject
import kotlin.math.max

/** Draws a [QrMatrix] into a crisp bitmap using the chosen design, optionally with a logo in the middle. */
class QrBitmapRenderer @Inject constructor() {

    fun render(matrix: QrMatrix, style: QrStyle, logo: Bitmap?): Bitmap {
        val modules = matrix.size
        // A whole number of pixels per module keeps square modules perfectly sharp.
        val scale = max(1, (style.sizePx + modules - 1) / modules)
        val side = scale * modules
        val bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888)
        QrDesignPainter.draw(Canvas(bitmap), matrix, style, logo, 0f, 0f, side.toFloat())
        return bitmap
    }
}
