package com.qrx.scanner.generator

/**
 * Visual options for a generated QR code. Colours are opaque ARGB ints.
 *
 * [foreground] and [background] are the plain colours (also used for contrast checks). [fill] and [eyeFill]
 * decide how the modules and the three eyes are actually painted, so a design can use gradients or a mix of colours.
 */
data class QrStyle(
    val foreground: Int,
    val background: Int,
    val sizePx: Int,
    val errorCorrection: ErrorCorrection,
    val design: QrDesign = QrDesigns.classic,
    val fill: QrFill = QrFill.solid(foreground),
    val eyeFill: QrFill? = null,
    /** Colour of the middle emblem; the main fill colour is used when this is null. */
    val emblemColor: Int? = null,
) {
    companion object {
        const val DEFAULT_FOREGROUND = 0xFF12152B.toInt()
        const val DEFAULT_BACKGROUND = 0xFFFFFFFF.toInt()
        const val DEFAULT_SIZE_PX = 1024
        val SIZES_PX = listOf(512, 1024, 2048)
    }
}
