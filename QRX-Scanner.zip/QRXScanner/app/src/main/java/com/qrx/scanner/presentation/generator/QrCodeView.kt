package com.qrx.scanner.presentation.generator

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.qrx.scanner.generator.QrDesignPainter
import com.qrx.scanner.generator.QrMatrix
import com.qrx.scanner.generator.QrStyle

/** Draws a QR matrix with the same painter the exporter uses, so what you see is what you save. */
@Composable
fun QrCodeView(
    matrix: QrMatrix,
    style: QrStyle,
    logo: Bitmap?,
    description: String,
    modifier: Modifier = Modifier,
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .semantics { contentDescription = description },
    ) {
        val side = size.width
        drawIntoCanvas { canvas ->
            QrDesignPainter.draw(canvas.nativeCanvas, matrix, style, logo, 0f, 0f, side)
        }
    }
}
