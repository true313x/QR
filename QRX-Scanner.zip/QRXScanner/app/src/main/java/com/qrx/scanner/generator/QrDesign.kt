package com.qrx.scanner.generator

/** Shape used for every data module of the code. The three big corner "eyes" are drawn separately. */
enum class ModuleShape {
    SQUARE,
    PIXEL,
    ROUNDED,
    DOT,
    DIAMOND,
    LIQUID,
    LEAF,
    LEAF_FLIP,
    HEART,
    BARS_HORIZONTAL,
    BARS_VERTICAL,
}

/** Shape of the frame (7x7) and of the ball (3x3) of the three corner eyes. */
enum class EyeShape { SQUARE, ROUNDED, CIRCLE, LEAF }

/** Small decoration drawn in the middle of the code when no logo was chosen. */
enum class QrEmblem { NONE, HEART, STAR }

enum class FillKind {
    SOLID,

    /** Colours blend along [QrFill.angleDegrees] (0 = left to right, 90 = top to bottom). */
    LINEAR,

    /** Colours blend from the centre of the code to its corners. */
    RADIAL,

    /** Every module takes one of the colours, spread in a fixed pattern. Only for single-module shapes. */
    MIX,
}

data class QrFill(
    val kind: FillKind,
    val colors: List<Int>,
    val angleDegrees: Float = 45f,
) {
    init {
        require(colors.isNotEmpty()) { "A fill needs at least one colour." }
    }

    /** The colour that stands for this fill when only one can be used (e.g. for contrast checks). */
    val primary: Int get() = colors.first()

    companion object {
        fun solid(color: Int): QrFill = QrFill(FillKind.SOLID, listOf(color))
    }
}

/**
 * A ready-made look for a QR code: module shape, eye shapes, colours and an optional emblem.
 * Every design keeps dark modules on a light background, because that is what scanners expect.
 */
data class QrDesign(
    val id: String,
    val module: ModuleShape = ModuleShape.SQUARE,
    val eyeFrame: EyeShape = EyeShape.SQUARE,
    val eyeBall: EyeShape = EyeShape.SQUARE,
    val fill: QrFill = QrFill.solid(DEFAULT_INK),
    /** Colour of the three eyes when it should differ from the modules. */
    val eyeFill: QrFill? = null,
    val background: Int = DEFAULT_PAPER,
    val emblem: QrEmblem = QrEmblem.NONE,
    val emblemColor: Int? = null,
    /** Thinner shapes lose scanning margin, so such designs ask for stronger error correction. */
    val minErrorCorrection: ErrorCorrection = ErrorCorrection.LOW,
    /** The best readability this design can ever reach, however good its colours are. */
    val scanRisk: Readability = Readability.GOOD,
) {
    companion object {
        const val DEFAULT_INK = 0xFF12152B.toInt()
        const val DEFAULT_PAPER = 0xFFFFFFFF.toInt()
    }
}

/** The built-in designs, in the order they are offered. The first one is the plain classic code. */
object QrDesigns {

    private fun rgb(value: Int): Int = 0xFF000000.toInt() or value

    private fun solid(value: Int): QrFill = QrFill.solid(rgb(value))

    private fun linear(angle: Float, vararg values: Int): QrFill =
        QrFill(FillKind.LINEAR, values.map { rgb(it) }, angle)

    private fun radial(vararg values: Int): QrFill = QrFill(FillKind.RADIAL, values.map { rgb(it) })

    private fun mix(vararg values: Int): QrFill = QrFill(FillKind.MIX, values.map { rgb(it) })

    val classic = QrDesign(id = "classic")

    val all: List<QrDesign> = listOf(
        classic,
        QrDesign(
            id = "rounded",
            module = ModuleShape.ROUNDED,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = solid(0x1B1F3B),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "dots",
            module = ModuleShape.DOT,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = solid(0x12152B),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "liquid",
            module = ModuleShape.LIQUID,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = linear(90f, 0x3D4FE0, 0x2A2F9E),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "leaf",
            module = ModuleShape.LEAF,
            eyeFrame = EyeShape.LEAF,
            eyeBall = EyeShape.LEAF,
            fill = solid(0x0B6E4F),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "petal",
            module = ModuleShape.LEAF_FLIP,
            eyeFrame = EyeShape.LEAF,
            eyeBall = EyeShape.LEAF,
            fill = solid(0x0B57D0),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "diamond",
            module = ModuleShape.DIAMOND,
            fill = solid(0x00695C),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "bars_h",
            module = ModuleShape.BARS_HORIZONTAL,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(90f, 0x6A1B9A, 0xAD1457),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "bars_v",
            module = ModuleShape.BARS_VERTICAL,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = linear(0f, 0x00796B, 0x0D2B52),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "pixel",
            module = ModuleShape.PIXEL,
            fill = solid(0x37474F),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "sunset",
            module = ModuleShape.DOT,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(45f, 0xE65100, 0xC2185B, 0x6A1B9A),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "ocean",
            module = ModuleShape.LIQUID,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(90f, 0x0B57D0, 0x006064),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "forest",
            module = ModuleShape.LEAF,
            eyeFrame = EyeShape.LEAF,
            eyeBall = EyeShape.CIRCLE,
            fill = radial(0x1B5E20, 0x00695C),
            background = rgb(0xF4FBF4),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "royal",
            module = ModuleShape.ROUNDED,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(45f, 0x4527A0, 0x1A237E),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "fire",
            module = ModuleShape.LIQUID,
            eyeFrame = EyeShape.LEAF,
            eyeBall = EyeShape.LEAF,
            fill = linear(90f, 0xB71C1C, 0xE65100),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "mint",
            module = ModuleShape.DOT,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(45f, 0x00695C, 0x1B5E20),
            background = rgb(0xE8F5E9),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "gold",
            module = ModuleShape.ROUNDED,
            eyeFrame = EyeShape.SQUARE,
            eyeBall = EyeShape.ROUNDED,
            fill = linear(45f, 0x212121, 0x8D6E00),
            background = rgb(0xFFF8E1),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "berry",
            module = ModuleShape.BARS_HORIZONTAL,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = linear(45f, 0x880E4F, 0x4A148C),
            background = rgb(0xFFF0F6),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "neon",
            module = ModuleShape.PIXEL,
            fill = mix(0x4527A0, 0xAD1457, 0x00695C, 0xE65100),
            eyeFill = solid(0x12152B),
            minErrorCorrection = ErrorCorrection.MEDIUM,
        ),
        QrDesign(
            id = "confetti",
            module = ModuleShape.DOT,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = mix(0xC62828, 0x1565C0, 0x2E7D32, 0x6A1B9A, 0xE65100),
            eyeFill = solid(0x12152B),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "heart_pixel",
            module = ModuleShape.PIXEL,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = mix(0x8E24AA, 0xAD1457, 0xD81B60, 0x6A1B9A),
            eyeFill = solid(0x7B1F5C),
            emblem = QrEmblem.HEART,
            emblemColor = rgb(0xE91E63),
        ),
        QrDesign(
            id = "heart_red",
            module = ModuleShape.ROUNDED,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = linear(45f, 0xC62828, 0xAD1457),
            background = rgb(0xFFF5F7),
            emblem = QrEmblem.HEART,
            emblemColor = rgb(0xE5173F),
        ),
        QrDesign(
            id = "love",
            module = ModuleShape.HEART,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(90f, 0xC2185B, 0x880E4F),
            background = rgb(0xFFF5F8),
            minErrorCorrection = ErrorCorrection.HIGH,
            scanRisk = Readability.RISKY,
        ),
        QrDesign(
            id = "star",
            module = ModuleShape.ROUNDED,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(90f, 0x5E35B1, 0x283593),
            emblem = QrEmblem.STAR,
            emblemColor = rgb(0xF9A825),
        ),
        QrDesign(
            id = "accent_eyes",
            module = ModuleShape.DOT,
            eyeFrame = EyeShape.ROUNDED,
            eyeBall = EyeShape.ROUNDED,
            fill = solid(0x303F9F),
            eyeFill = solid(0xB71C1C),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
        QrDesign(
            id = "sky",
            module = ModuleShape.DIAMOND,
            eyeFrame = EyeShape.CIRCLE,
            eyeBall = EyeShape.CIRCLE,
            fill = linear(45f, 0x0D47A1, 0x00838F),
            minErrorCorrection = ErrorCorrection.QUARTILE,
        ),
    )

    fun byId(id: String?): QrDesign = all.firstOrNull { it.id == id } ?: classic
}
