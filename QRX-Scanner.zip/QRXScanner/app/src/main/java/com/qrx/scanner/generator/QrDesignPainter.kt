package com.qrx.scanner.generator

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws a [QrMatrix] with a [QrDesign] onto any [Canvas]. The on-screen preview and the exported PNG both
 * call this, so what you see is exactly what you save.
 */
object QrDesignPainter {

    private const val EYE_MODULES = 7
    private const val EMBLEM_FRACTION = 0.24f
    private const val EMBLEM_HALO = 1.22f
    private const val HEART_STEPS = 72

    /** A heart outline with its centre at (0, 0) and its longest side equal to 1. Pairs of x, y. */
    private val heartUnit: FloatArray = buildHeart()

    /** Draws the code into the square starting at ([left], [top]) with the given [side] length. */
    fun draw(
        canvas: Canvas,
        matrix: QrMatrix,
        qrStyle: QrStyle,
        logo: Bitmap?,
        left: Float,
        top: Float,
        side: Float,
    ) {
        val saved = canvas.save()
        canvas.translate(left, top)
        canvas.drawRect(0f, 0f, side, side, solidPaint(qrStyle.background))

        val grid = Grid(matrix, side)
        val design = qrStyle.design
        val fill = qrStyle.fill
        val eyeFill = qrStyle.eyeFill ?: if (fill.kind == FillKind.MIX) QrFill.solid(fill.primary) else fill

        drawModules(canvas, grid, design.module, fill)
        drawEyes(canvas, grid, design, eyeFill)
        if (logo != null) {
            drawLogo(canvas, grid, qrStyle.background, logo)
        } else if (design.emblem != QrEmblem.NONE) {
            drawEmblem(canvas, grid, qrStyle)
        }
        canvas.restoreToCount(saved)
    }

    // region Grid

    private class Grid(val matrix: QrMatrix, val side: Float) {
        val count: Int = matrix.size
        val unit: Float = side / matrix.size
        private val near: Int = matrix.quietZone
        private val far: Int = matrix.quietZone + matrix.dataSize - EYE_MODULES

        /** Top-left module of the three finder patterns: top-left, top-right, bottom-left. */
        val eyeOrigins: List<Pair<Int, Int>> = listOf(near to near, far to near, near to far)

        fun isEye(x: Int, y: Int): Boolean {
            for (origin in eyeOrigins) {
                if (x >= origin.first && x < origin.first + EYE_MODULES &&
                    y >= origin.second && y < origin.second + EYE_MODULES
                ) {
                    return true
                }
            }
            return false
        }

        /** A dark data module. Modules inside the three eyes are not data; they are drawn by [drawEyes]. */
        fun dark(x: Int, y: Int): Boolean =
            x >= 0 && y >= 0 && x < count && y < count && matrix[x, y] && !isEye(x, y)
    }

    // endregion

    // region Paints

    private fun solidPaint(color: Int): Paint {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = color
        return paint
    }

    private fun fillPaint(fill: QrFill, side: Float): Paint {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = fill.primary
        val colors = fill.colors.toIntArray()
        if (fill.kind == FillKind.LINEAR && colors.size > 1) {
            val radians = Math.toRadians(fill.angleDegrees.toDouble())
            val dx = cos(radians).toFloat()
            val dy = sin(radians).toFloat()
            val half = (abs(dx) + abs(dy)) * side / 2f
            val middle = side / 2f
            paint.shader = LinearGradient(
                middle - dx * half,
                middle - dy * half,
                middle + dx * half,
                middle + dy * half,
                colors,
                null,
                Shader.TileMode.CLAMP,
            )
        } else if (fill.kind == FillKind.RADIAL && colors.size > 1) {
            paint.shader = RadialGradient(side / 2f, side / 2f, side * 0.62f, colors, null, Shader.TileMode.CLAMP)
        }
        return paint
    }

    // endregion

    // region Modules

    private fun drawModules(canvas: Canvas, grid: Grid, shape: ModuleShape, fill: QrFill) {
        val paint = fillPaint(fill, grid.side)
        val path = Path()

        if (fill.kind == FillKind.MIX) {
            // One draw per module so every module can take its own colour.
            for (y in 0 until grid.count) {
                for (x in 0 until grid.count) {
                    if (!grid.dark(x, y)) continue
                    path.rewind()
                    addModule(path, grid, shape, x, y)
                    paint.color = fill.colors[mixIndex(x, y, fill.colors.size)]
                    canvas.drawPath(path, paint)
                }
            }
            return
        }

        when (shape) {
            ModuleShape.BARS_HORIZONTAL -> addBars(path, grid, horizontal = true)
            ModuleShape.BARS_VERTICAL -> addBars(path, grid, horizontal = false)
            else -> {
                for (y in 0 until grid.count) {
                    for (x in 0 until grid.count) {
                        if (grid.dark(x, y)) addModule(path, grid, shape, x, y)
                    }
                }
            }
        }
        canvas.drawPath(path, paint)
    }

    private fun mixIndex(x: Int, y: Int, size: Int): Int = (x * 7 + y * 13 + x * y) % size

    private fun addModule(path: Path, grid: Grid, shape: ModuleShape, x: Int, y: Int) {
        val unit = grid.unit
        val left = x * unit
        val top = y * unit
        val right = (x + 1) * unit
        val bottom = (y + 1) * unit
        val centerX = (left + right) / 2f
        val centerY = (top + bottom) / 2f

        when (shape) {
            ModuleShape.SQUARE -> path.addRect(left, top, right, bottom, Path.Direction.CW)
            ModuleShape.PIXEL -> {
                val inset = unit * 0.09f
                path.addRect(left + inset, top + inset, right - inset, bottom - inset, Path.Direction.CW)
            }
            ModuleShape.ROUNDED, ModuleShape.BARS_HORIZONTAL, ModuleShape.BARS_VERTICAL -> {
                val inset = unit * 0.05f
                val radius = unit * 0.32f
                path.addRoundRect(left + inset, top + inset, right - inset, bottom - inset, radius, radius, Path.Direction.CW)
            }
            ModuleShape.DOT -> path.addCircle(centerX, centerY, unit * 0.47f, Path.Direction.CW)
            ModuleShape.DIAMOND -> {
                val half = unit * 0.58f
                path.moveTo(centerX, centerY - half)
                path.lineTo(centerX + half, centerY)
                path.lineTo(centerX, centerY + half)
                path.lineTo(centerX - half, centerY)
                path.close()
            }
            ModuleShape.LIQUID -> {
                // Only the corners that do not touch a neighbouring module are rounded, so modules flow together.
                val up = grid.dark(x, y - 1)
                val down = grid.dark(x, y + 1)
                val before = grid.dark(x - 1, y)
                val after = grid.dark(x + 1, y)
                val radius = unit * 0.5f
                addCorners(
                    path, left, top, right, bottom,
                    topLeft = if (up || before) 0f else radius,
                    topRight = if (up || after) 0f else radius,
                    bottomRight = if (down || after) 0f else radius,
                    bottomLeft = if (down || before) 0f else radius,
                )
            }
            ModuleShape.LEAF -> {
                val radius = unit * 0.5f
                addCorners(path, left, top, right, bottom, radius, 0f, radius, 0f)
            }
            ModuleShape.LEAF_FLIP -> {
                val radius = unit * 0.5f
                addCorners(path, left, top, right, bottom, 0f, radius, 0f, radius)
            }
            ModuleShape.HEART -> addHeart(path, centerX, centerY + unit * 0.02f, unit * 1.05f)
        }
    }

    private fun addBars(path: Path, grid: Grid, horizontal: Boolean) {
        val unit = grid.unit
        val pad = unit * 0.09f
        for (lane in 0 until grid.count) {
            var start = 0
            while (start < grid.count) {
                val startsHere = if (horizontal) grid.dark(start, lane) else grid.dark(lane, start)
                if (!startsHere) {
                    start++
                    continue
                }
                var end = start
                while (end + 1 < grid.count) {
                    val continues = if (horizontal) grid.dark(end + 1, lane) else grid.dark(lane, end + 1)
                    if (!continues) break
                    end++
                }
                val bar = if (horizontal) {
                    RectF(start * unit, lane * unit + pad, (end + 1) * unit, (lane + 1) * unit - pad)
                } else {
                    RectF(lane * unit + pad, start * unit, (lane + 1) * unit - pad, (end + 1) * unit)
                }
                val radius = min(bar.width(), bar.height()) / 2f
                path.addRoundRect(bar, radius, radius, Path.Direction.CW)
                start = end + 1
            }
        }
    }

    private fun addCorners(
        path: Path,
        left: Float,
        top: Float,
        right: Float,
        bottom: Float,
        topLeft: Float,
        topRight: Float,
        bottomRight: Float,
        bottomLeft: Float,
    ) {
        val radii = floatArrayOf(
            topLeft, topLeft,
            topRight, topRight,
            bottomRight, bottomRight,
            bottomLeft, bottomLeft,
        )
        path.addRoundRect(RectF(left, top, right, bottom), radii, Path.Direction.CW)
    }

    // endregion

    // region Eyes

    private fun drawEyes(canvas: Canvas, grid: Grid, design: QrDesign, eyeFill: QrFill) {
        val paint = fillPaint(eyeFill, grid.side)
        // Even-odd: the frame is filled, the gap inside it is empty and the ball inside the gap is filled again.
        val path = Path()
        path.fillType = Path.FillType.EVEN_ODD
        val unit = grid.unit
        for (origin in grid.eyeOrigins) {
            val x = origin.first * unit
            val y = origin.second * unit
            addEyeShape(path, design.eyeFrame, x, y, 7f * unit, 1.9f * unit, 3.2f * unit)
            addEyeShape(path, design.eyeFrame, x + unit, y + unit, 5f * unit, 0.9f * unit, 2.2f * unit)
            addEyeShape(path, design.eyeBall, x + 2f * unit, y + 2f * unit, 3f * unit, 0.9f * unit, 1.5f * unit)
        }
        canvas.drawPath(path, paint)
    }

    private fun addEyeShape(
        path: Path,
        shape: EyeShape,
        left: Float,
        top: Float,
        size: Float,
        roundedRadius: Float,
        leafRadius: Float,
    ) {
        val right = left + size
        val bottom = top + size
        when (shape) {
            EyeShape.SQUARE -> path.addRect(left, top, right, bottom, Path.Direction.CW)
            EyeShape.ROUNDED -> path.addRoundRect(left, top, right, bottom, roundedRadius, roundedRadius, Path.Direction.CW)
            EyeShape.CIRCLE -> path.addCircle(left + size / 2f, top + size / 2f, size / 2f, Path.Direction.CW)
            EyeShape.LEAF -> addCorners(path, left, top, right, bottom, leafRadius, 0f, leafRadius, 0f)
        }
    }

    // endregion

    // region Logo and emblem

    private fun drawLogo(canvas: Canvas, grid: Grid, background: Int, logo: Bitmap) {
        val center = grid.side / 2f
        val dataSide = grid.matrix.dataSize * grid.unit
        val logoSide = dataSide * QrLogoGeometry.LOGO_FRACTION
        val plateHalf = dataSide * QrLogoGeometry.PLATE_FRACTION / 2f

        val radius = plateHalf * 0.22f
        canvas.drawRoundRect(
            RectF(center - plateHalf, center - plateHalf, center + plateHalf, center + plateHalf),
            radius,
            radius,
            solidPaint(background),
        )

        val fit = min(logoSide / logo.width, logoSide / logo.height)
        val halfWidth = logo.width * fit / 2f
        val halfHeight = logo.height * fit / 2f
        val destination = RectF(center - halfWidth, center - halfHeight, center + halfWidth, center + halfHeight)
        canvas.drawBitmap(logo, null, destination, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
    }

    private fun drawEmblem(canvas: Canvas, grid: Grid, qrStyle: QrStyle) {
        val design = qrStyle.design
        val center = grid.side / 2f
        val size = grid.matrix.dataSize * grid.unit * EMBLEM_FRACTION
        val halo = Path()
        val body = Path()
        when (design.emblem) {
            QrEmblem.HEART -> {
                addHeart(halo, center, center + size * EMBLEM_HALO * 0.02f, size * EMBLEM_HALO)
                addHeart(body, center, center + size * 0.02f, size)
            }
            QrEmblem.STAR -> {
                addStar(halo, center, center + size * EMBLEM_HALO * 0.03f, size * 1.15f * EMBLEM_HALO)
                addStar(body, center, center + size * 0.03f, size * 1.15f)
            }
            QrEmblem.NONE -> return
        }
        canvas.drawPath(halo, solidPaint(qrStyle.background))
        canvas.drawPath(body, solidPaint(qrStyle.emblemColor ?: qrStyle.fill.primary))
    }

    // endregion

    // region Outlines

    private fun buildHeart(): FloatArray {
        val xs = DoubleArray(HEART_STEPS)
        val ys = DoubleArray(HEART_STEPS)
        for (i in 0 until HEART_STEPS) {
            val t = 2.0 * Math.PI * i / HEART_STEPS
            val s = sin(t)
            xs[i] = 16.0 * s * s * s
            ys[i] = -(13.0 * cos(t) - 5.0 * cos(2.0 * t) - 2.0 * cos(3.0 * t) - cos(4.0 * t))
        }
        var minX = xs[0]
        var maxX = xs[0]
        var minY = ys[0]
        var maxY = ys[0]
        for (i in 1 until HEART_STEPS) {
            minX = min(minX, xs[i])
            maxX = max(maxX, xs[i])
            minY = min(minY, ys[i])
            maxY = max(maxY, ys[i])
        }
        val scale = 1.0 / max(maxX - minX, maxY - minY)
        val midX = (minX + maxX) / 2.0
        val midY = (minY + maxY) / 2.0
        val points = FloatArray(HEART_STEPS * 2)
        for (i in 0 until HEART_STEPS) {
            points[i * 2] = ((xs[i] - midX) * scale).toFloat()
            points[i * 2 + 1] = ((ys[i] - midY) * scale).toFloat()
        }
        return points
    }

    private fun addHeart(path: Path, centerX: Float, centerY: Float, size: Float) {
        for (i in 0 until HEART_STEPS) {
            val x = centerX + heartUnit[i * 2] * size
            val y = centerY + heartUnit[i * 2 + 1] * size
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    private fun addStar(path: Path, centerX: Float, centerY: Float, size: Float) {
        val outer = size / 2f
        val inner = outer * 0.46f
        for (i in 0 until 10) {
            val angle = -Math.PI / 2.0 + i * Math.PI / 5.0
            val radius = if (i % 2 == 0) outer else inner
            val x = centerX + (radius * cos(angle)).toFloat()
            val y = centerY + (radius * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    // endregion
}
