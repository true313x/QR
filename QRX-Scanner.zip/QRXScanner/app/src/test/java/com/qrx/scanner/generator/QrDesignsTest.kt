package com.qrx.scanner.generator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class QrDesignsTest {

    @Test
    fun offersTheClassicCodePlusTwentyFiveDesigns() {
        assertEquals(26, QrDesigns.all.size)
        assertSame(QrDesigns.classic, QrDesigns.all.first())
    }

    @Test
    fun idsAreUnique() {
        assertEquals(QrDesigns.all.size, QrDesigns.all.map { it.id }.toSet().size)
    }

    @Test
    fun unknownIdFallsBackToClassic() {
        assertSame(QrDesigns.classic, QrDesigns.byId("nope"))
        assertSame(QrDesigns.classic, QrDesigns.byId(null))
    }

    @Test
    fun everyColourKeepsEnoughContrastOnItsBackground() {
        for (design in QrDesigns.all) {
            val colors = design.fill.colors + (design.eyeFill?.colors ?: emptyList())
            for (color in colors) {
                val ratio = ReadabilityEvaluator.contrastRatio(color, design.background)
                assertTrue("${design.id} has contrast $ratio", ratio >= 3.0)
            }
        }
    }

    @Test
    fun mixedFillsOnlyUseShapesThatAreDrawnModuleByModule() {
        for (design in QrDesigns.all.filter { it.fill.kind == FillKind.MIX }) {
            assertTrue(design.id, design.module != ModuleShape.BARS_HORIZONTAL && design.module != ModuleShape.BARS_VERTICAL)
        }
    }

    @Test
    fun emblemDesignsDoNotClaimToBeRisky() {
        for (design in QrDesigns.all.filter { it.emblem != QrEmblem.NONE }) {
            assertEquals(design.id, Readability.GOOD, design.scanRisk)
        }
    }
}
